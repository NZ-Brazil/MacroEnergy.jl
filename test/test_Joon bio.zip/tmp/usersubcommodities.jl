abstract type Bagasse <: MacroEnergy.Biomass end
abstract type Corn <: MacroEnergy.Biomass end
abstract type Ethanol <: MacroEnergy.LiquidFuels end
