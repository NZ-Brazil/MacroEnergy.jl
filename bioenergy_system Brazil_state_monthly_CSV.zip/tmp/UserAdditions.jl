module UserAdditions
using MacroEnergy

commodities_path = raw"g:\My Drive\=== Princeton 연구 ===\Model_MACRO\MacroEnergy.jl\bioenergy_system Brazil_state_monthly_CSV\tmp\usersubcommodities.jl"
if isfile(commodities_path)
    include(commodities_path)
end

assets_path = raw"g:\My Drive\=== Princeton 연구 ===\Model_MACRO\MacroEnergy.jl\bioenergy_system Brazil_state_monthly_CSV\tmp\userassets.jl"
if isfile(assets_path)
    include(assets_path)
end

end
